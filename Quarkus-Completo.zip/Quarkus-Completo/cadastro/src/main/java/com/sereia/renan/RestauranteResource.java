package com.sereia.renan;

import com.sereia.renan.cadastro.Prato;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import com.sereia.renan.cadastro.Restaurente;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.eclipse.microprofile.openapi.annotations.tags.Tags;

import java.util.List;
import java.util.Optional;

@Path("/restaurantes")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name = "restaurante")
public class RestauranteResource {

    @GET
    public List<Restaurente> listAll() {
        return Restaurente.listAll();
    }

    @POST
    @Transactional
    public void adicionar(Restaurente dto){
        dto.persist();
    }

    @PUT
    @Path("{id}")
    @Transactional
    public void atualizar(@PathParam("id") Long id,Restaurente dto){
        Optional<Restaurente> byId = Restaurente.findByIdOptional(id);
        if (byId.isEmpty()){
            throw new NotFoundException();
        }

        Restaurente restaurente = byId.get();
        restaurente.nome = dto.nome;

        restaurente.persist();
    }

    @DELETE
    @Path("{id}")
    @Transactional
    public void delete(@PathParam("id") Long id){
        Optional<Restaurente> obj = Restaurente.findByIdOptional(id);

        obj.ifPresentOrElse(Restaurente::delete, () -> {
            throw new NotFoundException();
        });

    }

    //Pratos

    @GET
    @Path("{idRestaurante}/pratos")
    @Tag(name = "prato")
    @Tag(name = "restaurante")
    public List<Prato> buscarPrato(@PathParam("idRestaurante") Long idRestaurante){
        Optional<Restaurente> restaurenteId = Restaurente.findByIdOptional(idRestaurante);

        if (restaurenteId.isEmpty()) throw new NotFoundException("Restaurante não encontrado");

        return Prato.list("restaurante", restaurenteId.get());
    }

    @POST
    @Path("{idRestaurante}/pratos")
    @Transactional
    @Tag(name = "prato")
    public Response adicionarPrato(@PathParam("idRestaurante") Long idRestaurante, Prato dto){
        Optional<Restaurente> restaurenteId = Restaurente.findByIdOptional(idRestaurante);

        if (restaurenteId.isEmpty()) throw new NotFoundException("Restaurante não encontrado");

        Prato prato = new Prato();
        prato.nome = dto.nome;
        prato.preco = dto.preco;
        prato.restaurente = restaurenteId.get();

        prato.persist();

        return Response.status(Response.Status.CREATED).build();
    }

    @PUT
    @Path("{idRestaurante}/pratos/{id}")
    @Transactional
    @Tag(name = "prato")
    public void atualizar(@PathParam("idRestaurante")Long idRestaurante,@PathParam("id")Long idPrato, Prato dto){
        Optional<Restaurente> restaurenteId = Restaurente.findByIdOptional(idRestaurante);

        if (restaurenteId.isEmpty()) throw new NotFoundException("Restaurante não encontrado");

        Optional<Prato> pratoId = Prato.findByIdOptional(idPrato);

        if (pratoId.isEmpty()) throw new NotFoundException("Prato não encontrado");

        Prato prato = pratoId.get();
        prato.nome = dto.nome;
        prato.preco = dto.preco;
        prato.restaurente = dto.restaurente;
        prato.persist();

    }

    @DELETE
    @Path("{idRestaurante}/pratos/{id}")
    @Transactional
    @Tag(name = "prato")
    public void deletePrato(@PathParam("idRestaurante")Long idRestaurante,@PathParam("id") Long id){
        Optional<Restaurente> restaurenteId = Restaurente.findByIdOptional(idRestaurante);

        if (restaurenteId.isEmpty()) throw new NotFoundException("Restaurante não encontrado");

        Optional<Prato> pratoId = Prato.findByIdOptional(id);

        if (pratoId.isEmpty()) throw new NotFoundException("Prato não encontrado");

        pratoId
                .ifPresentOrElse(Prato::delete,
                        ()-> {throw new NotFoundException();});
    }
}
