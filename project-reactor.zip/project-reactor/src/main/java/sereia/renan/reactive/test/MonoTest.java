package sereia.renan.reactive.test;

public class MonoTest {
}
